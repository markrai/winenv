#NoTrayIcon
^+d::
FormatTime, time, A_now, ddd d-MMM-yyyy hh:mm tt
send %time%
return

