#NoTrayIcon
!q::Send !{F4}
return
