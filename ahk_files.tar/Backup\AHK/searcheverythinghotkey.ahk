﻿#NoTrayIcon
#s::
send ^+s
return