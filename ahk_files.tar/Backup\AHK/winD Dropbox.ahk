#NoTrayIcon
#d::
Run, "D:\"
return
