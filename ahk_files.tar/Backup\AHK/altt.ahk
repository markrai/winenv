#NoTrayIcon
!t::Send ^{t}
return
