#NoTrayIcon
!LWin::
KeyWait, Alt
Send {AppsKey}
Return
