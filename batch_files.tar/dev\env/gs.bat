@ECHO OFF
git status