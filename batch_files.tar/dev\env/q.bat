@ECHO OFF
exit