@ECHO OFF
cd C:\dev\projects\python-lambda