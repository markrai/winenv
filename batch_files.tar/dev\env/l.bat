@ECHO OFF
dir