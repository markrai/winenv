start c:\dev\projects
notepad c:\dev\env\p.bat
