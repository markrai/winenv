@ECHO OFF
git add .